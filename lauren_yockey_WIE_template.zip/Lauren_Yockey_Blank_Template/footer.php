<!-- Begin Footer -->
    <footer class="row">

      <div class="four columns">
        <?php dynamic_sidebar('footer-widget-one'); ?>
      </div>

      <div class="four columns">
        <?php dynamic_sidebar('footer-widget-two'); ?>
      </div>

      <div class="four columns">
        <?php dynamic_sidebar('footer-widget-three'); ?>
      </div>


    </footer>

  </div><!--End Container Div-->
  <?php wp_footer(); ?>

</body>
</html>
<!-- End Footer -->
